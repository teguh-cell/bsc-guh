
export default function Home() {
  return (
    <div style={{ padding: 20 }}>
      <h1>BSC Guh Dashboard</h1>
      <p>Silakan sesuaikan Balanced Scorecard, Risk Management, dan Business Model di sini.</p>
    </div>
  );
}
